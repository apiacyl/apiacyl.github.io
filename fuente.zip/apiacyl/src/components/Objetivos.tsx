
import React, { useRef, useEffect } from 'react';
import { Info, Users, Shield } from 'lucide-react';

const Objetivos: React.FC = () => {
  const objetivosRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    const childElements = objetivosRef.current?.querySelectorAll('.objetivo-card');
    childElements?.forEach((el) => {
      observer.observe(el);
    });

    return () => {
      childElements?.forEach((el) => {
        observer.unobserve(el);
      });
    };
  }, []);

  return (
    <section id="objetivos" className="bg-green-50/50 py-20">
      <div className="section-padding" ref={objetivosRef}>
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Nuestros Objetivos</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Como asociación, APIACYL trabaja para nuestro colectivo en tres pilares fundamentales:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="objetivo-card glass p-8 opacity-0 translate-y-10 transition-all duration-700 delay-100">
            <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto">
              <Info className="text-primary" size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">Informar</h3>
            <p className="text-muted-foreground text-center">
              Ofrecer información relevante, veraz y actualizada sobre los aspectos que afectan al colectivo: normativas, problemática,
              tecnologías y oportunidades para nuestros profesionales informáticos.
            </p>
          </div>

          <div className="objetivo-card glass p-8 opacity-0 translate-y-10 transition-all duration-700 delay-200">
            <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto">
              <Users className="text-primary" size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">Representar</h3>
            <p className="text-muted-foreground text-center">
              Actuar como voz colectiva unificada ante los órganos de la administración de Castilla y León. 
              Defender los intereses profesionales y promover el reconocimiento que debe tener la labor informática en la administración de Castilla y León como eje transversal de su actividad.
            </p>
          </div>

          <div className="objetivo-card glass p-8 opacity-0 translate-y-10 transition-all duration-700 delay-300">
            <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto">
              <Shield className="text-primary" size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center">Defender</h3>
            <p className="text-muted-foreground text-center">
              Proteger los derechos laborales y profesionales de nuestros asociados. Reclamar en justicia la equiparación y mejora de las condiciones y el reconocimiento del colectivo 
              informático en Castilla y León al mismo nivel de otras administraciones.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Objetivos;
