
import React, { useEffect, useRef } from 'react';
import { Mail, QrCode } from 'lucide-react';

const Contact: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    if (infoRef.current) {
      observer.observe(infoRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
      if (infoRef.current) {
        observer.unobserve(infoRef.current);
      }
    };
  }, []);

  return (
    <section id="contacto" className="bg-white py-20">
      <div
        ref={sectionRef}
        className="section-padding opacity-0 translate-y-10 transition-all duration-1000"
      >
        <div className="text-center mb-16">
          <div className="inline-block px-3 py-1 mb-4 bg-blue-50 rounded-full">
            <span className="text-primary text-sm font-medium">Contáctanos</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">¿Cómo podemos ayudarte?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Estamos aquí para responder tus preguntas y atender tus inquietudes. No dudes en contactarnos.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div
            ref={infoRef}
            className="opacity-0 translate-y-10 transition-all duration-1000"
          >
            <div className="bg-blue-50 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-6 text-center">Información de contacto</h3>
              
              <div className="space-y-6">
                <div className="flex flex-col items-center text-center">
                  <div className="mb-2">
                    <Mail className="h-6 w-6 text-primary mx-auto" />
                  </div>
                  <div>
                    <h4 className="text-lg font-medium">Correo electrónico</h4>
                    <p className="text-muted-foreground">
                      <a href="mailto:info.apiacyl@gmail.com" className="hover:text-primary transition-colors">
                        info.apiacyl@gmail.com
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex flex-col items-center text-center">
                  <div className="mb-2">
                    <QrCode className="h-6 w-6 text-primary mx-auto" />
                  </div>
                  <div>
                    <h4 className="text-lg font-medium">Grupo de Telegram</h4>
                    <p className="text-muted-foreground mb-2">
                      <a href="https://t.me/+6KILlb9q_LkwMTY0" className="hover:text-primary transition-colors" target="_blank" rel="noopener noreferrer">
                        Únete a nuestro grupo
                      </a>
                    </p>
                    <div className="mt-4">
                      <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://t.me/+6KILlb9q_LkwMTY0" 
                        alt="QR Code para Telegram" 
                        className="h-32 w-32 border border-border rounded shadow-sm mx-auto" 
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
