
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  description: string;
  date: string;
  category: string;
  content: string;
}

const NewsDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [newsItem, setNewsItem] = useState<NewsItem | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNewsItem = async () => {
      try {
        if (!id) return;
        // Dynamic import based on the ID
        const newsItemModule = await import(`../data/news/card${id}.json`);
        setNewsItem(newsItemModule);
        setLoading(false);
      } catch (error) {
        console.error('Error loading news item:', error);
        setLoading(false);
      }
    };

    fetchNewsItem();
  }, [id]);

  const handleBack = () => {
    navigate(-1);
  };

  if (loading) {
    return (
      <Layout>
        <div className="section-padding py-20">
          <div className="container mx-auto">
            <p>Cargando...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!newsItem) {
    return (
      <Layout>
        <div className="section-padding py-20">
          <div className="container mx-auto">
            <h1 className="text-3xl font-bold mb-6">Noticia no encontrada</h1>
            <Button onClick={handleBack} variant="outline" className="mb-8">
              <ArrowLeft className="mr-2 h-4 w-4" /> Volver
            </Button>
            <p>La noticia que estás buscando no existe o ha sido eliminada.</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="section-padding py-20">
        <div className="container mx-auto max-w-4xl">
          <Button onClick={handleBack} variant="outline" className="mb-8">
            <ArrowLeft className="mr-2 h-4 w-4" /> Volver
          </Button>
          
          <article className="bg-white p-8 rounded-lg shadow-sm border border-border">
            <div className="flex justify-between items-center mb-4">
              <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-50 text-primary rounded-full">
                {newsItem.category}
              </span>
              <span className="text-sm text-muted-foreground">{newsItem.date}</span>
            </div>
            
            <h1 className="text-3xl font-bold mb-6">{newsItem.title}</h1>
            
            <div className="prose max-w-none">
              <p className="text-lg font-medium mb-6">{newsItem.description}</p>
              
              {/* Render the content from the JSON file */}
              <div dangerouslySetInnerHTML={{ __html: newsItem.content || '' }} />
            </div>
            
            <div className="mt-8 pt-6 border-t border-border">
              <Button onClick={handleBack} variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" /> Volver a novedades
              </Button>
            </div>
          </article>
        </div>
      </div>
    </Layout>
  );
};

export default NewsDetail;
