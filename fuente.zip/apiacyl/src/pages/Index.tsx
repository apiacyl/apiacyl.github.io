
import React from 'react';
import Layout from '../components/Layout';
import Hero from '../components/Hero';
import Objetivos from '../components/Objetivos';
import News from '../components/News';
import Join from '../components/Join';
import Contact from '../components/Contact';

const Index = () => {
  return (
    <Layout>
      <Hero />
      <div id="about">
        <Objetivos />
      </div>
      <News />
      <Join />
      <Contact />
    </Layout>
  );
};

export default Index;
