
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { Card, CardContent } from '../components/ui/card';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui/button';

interface NewsItem {
  id: number;
  title: string;
  description: string;
  date: string;
  category: string;
}

const NewsListPage: React.FC = () => {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadNews = async () => {
      try {
        // Dynamic import of all news cards
        const card1 = await import('../data/news/card1.json');
        const card2 = await import('../data/news/card2.json');
        const card3 = await import('../data/news/card3.json');
        
        // Sort by id to maintain order
        const allCards = [card1, card2, card3].sort((a, b) => a.id - b.id);
        setNewsItems(allCards);
        setLoading(false);
      } catch (error) {
        console.error('Error loading news cards:', error);
        setLoading(false);
      }
    };

    loadNews();
  }, []);

  return (
    <Layout>
      <div className="section-padding py-20">
        <div className="container mx-auto max-w-6xl">
          <Button asChild variant="outline" className="mb-8">
            <Link to="/">
              <ArrowLeft className="mr-2 h-4 w-4" /> Volver a inicio
            </Link>
          </Button>
          
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 mb-4 bg-blue-50 rounded-full">
              <span className="text-primary text-sm font-medium">Actualidad</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Todas las novedades</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Mantente al día con las últimas noticias, eventos y actividades de nuestra asociación.
            </p>
          </div>

          {loading ? (
            <p className="text-center">Cargando novedades...</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {newsItems.map((item) => (
                <Card key={item.id} className="bg-white border border-border rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <span className="inline-block px-2 py-1 text-xs font-medium bg-blue-50 text-primary rounded-full">
                        {item.category}
                      </span>
                      <span className="text-xs text-muted-foreground">{item.date}</span>
                    </div>
                    <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                    <p className="text-muted-foreground mb-4">{item.description}</p>
                    <Link
                      to={`/noticias/${item.id}`}
                      className="inline-flex items-center text-primary hover:underline"
                    >
                      Leer más
                      <ArrowRight className="ml-1 w-4 h-4" />
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default NewsListPage;
