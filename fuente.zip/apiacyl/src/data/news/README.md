
# Cómo actualizar las Novedades

Para añadir o modificar tarjetas de noticias en la sección de Novedades:

1. Cada tarjeta de noticias está almacenada como un archivo JSON independiente en este directorio.
2. Para añadir una nueva noticia, crea un nuevo archivo JSON siguiendo el formato de los existentes.
3. Para modificar una noticia existente, edita el archivo JSON correspondiente.

## Formato del archivo JSON

```json
{
  "id": 4,                                           // Número único para identificar la noticia
  "title": "Título de la noticia",                   // Título de la noticia
  "description": "Descripción de la noticia...",     // Descripción breve
  "date": "30 Agosto, 2023",                         // Fecha en formato legible
  "category": "Categoría",                           // Categoría de la noticia
  "content": "<p>Contenido completo de la noticia...</p>" // Contenido HTML para la página de detalle
}
```

## Ejemplo de nuevo archivo (card4.json)

```json
{
  "id": 4,
  "title": "Nuevo curso de formación",
  "description": "Abrimos inscripciones para el nuevo curso de formación en tecnologías emergentes.",
  "date": "30 Agosto, 2023",
  "category": "Formación",
  "content": "<p>El nuevo curso de formación estará centrado en las siguientes áreas:</p><ul><li>Inteligencia artificial</li><li>Blockchain</li><li>Cloud computing</li></ul><p>Las inscripciones estarán abiertas hasta el 15 de septiembre.</p>"
}
```

## Formato del contenido HTML

El campo `content` acepta HTML básico para dar formato al contenido detallado de la noticia:

- Usar `<p>` para párrafos.
- Usar `<ul>` y `<li>` para listas.
- Usar `<h3>` para subtítulos (no usar h1 o h2 que están reservados para la estructura de la página).
- Usar `<strong>` para texto en negrita.
- Usar `<em>` para texto en cursiva.
- Usar `<a href="URL">texto</a>` para enlaces.

Nota: Para que una nueva tarjeta aparezca en la web, es necesario añadirla también en el archivo `src/components/News.tsx`. Busca la sección donde se importan las tarjetas y añade la nueva.
