
import React, { useEffect, useRef } from 'react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (heroRef.current) {
      observer.observe(heroRef.current);
    }

    return () => {
      if (heroRef.current) {
        observer.unobserve(heroRef.current);
      }
    };
  }, []);

  return (
    <section
      id="inicio"
      className="relative h-screen flex items-center justify-center overflow-hidden pt-16"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-green-50 to-transparent opacity-70 z-0"></div>
      <div
        ref={heroRef}
        className="section-padding z-10 text-center opacity-0 translate-y-10 transition-all duration-1000"
      >
        <div className="flex justify-center mb-4">
          <img 
            src="/lovable-uploads/e1c32114-b210-4120-80fc-542c02894466.png" 
            alt="APIACYL Logo" 
            className="h-32" /* Scaled to 75% of previous size (h-42 → h-32) */
          />
        </div>
        
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
          <span className="text-primary">APIACYL</span>
          <div className="mt-4 mb-6"> {/* Added more space between APIACYL and the rest */}
            <span className="text-muted-foreground">Asociación de Profesionales Informáticos</span><br />
            <span className="text-muted-foreground">de la Administración de Castilla y León</span>
          </div>
        </h1>
        <p className="text-muted-foreground max-w-xl mx-auto mb-8 text-lg">
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#objetivos" className="btn-primary">
            Nuestros objetivos
          </a>
          <a href="#contacto" className="btn-outline">
            Contáctanos
          </a>
        </div>
        
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <a href="#objetivos" className="text-muted-foreground hover:text-primary transition-colors">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 5v14M5 12l7 7 7-7" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
