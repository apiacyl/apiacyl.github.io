
import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from './ui/card';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

// Import all news cards dynamically
// To add a new card, simply create a new JSON file in the data/news directory
interface NewsItem {
  id: number;
  title: string;
  description: string;
  date: string;
  category: string;
}

const News: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);

  // Load news from JSON files
  useEffect(() => {
    const loadNews = async () => {
      try {
        // Dynamic import of all news cards
        const card1 = await import('../data/news/card1.json');
        const card2 = await import('../data/news/card2.json');
        const card3 = await import('../data/news/card3.json');
        
        // Sort by id to maintain order
        const allCards = [card1, card2, card3].sort((a, b) => a.id - b.id);
        setNewsItems(allCards);
      } catch (error) {
        console.error('Error loading news cards:', error);
      }
    };

    loadNews();
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    cardRefs.current.forEach((card) => {
      if (card) observer.observe(card);
    });

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
      cardRefs.current.forEach((card) => {
        if (card) observer.unobserve(card);
      });
    };
  }, [newsItems.length]);

  return (
    <section id="novedades" className="bg-white py-20">
      <div
        ref={sectionRef}
        className="section-padding opacity-0 translate-y-10 transition-all duration-1000"
      >
        <div className="text-center mb-16">
          <div className="inline-block px-3 py-1 mb-4 bg-blue-50 rounded-full">
            <span className="text-primary text-sm font-medium">Actualidad</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Novedades</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Mantente al día con las últimas noticias, eventos y actividades de nuestra asociación.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <Card
              key={item.id}
              ref={(el) => (cardRefs.current[index] = el)}
              className="bg-white border border-border rounded-lg shadow-sm overflow-hidden card-hover opacity-0 translate-y-10 transition-all"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="inline-block px-2 py-1 text-xs font-medium bg-blue-50 text-primary rounded-full">
                    {item.category}
                  </span>
                  <span className="text-xs text-muted-foreground">{item.date}</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-muted-foreground mb-4">{item.description}</p>
                <Link
                  to={`/noticias/${item.id}`}
                  className="inline-flex items-center text-primary hover:underline"
                >
                  Leer más
                  <ArrowRight className="ml-1 w-4 h-4" />
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link to="/noticias" className="btn-primary">
            Ver todas las novedades
          </Link>
        </div>
      </div>
    </section>
  );
};

export default News;
