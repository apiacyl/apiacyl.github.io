
import React, { useEffect, useRef } from 'react';
import { FileText, Mail } from 'lucide-react';
import { Button } from './ui/button';

const Join: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-10');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    if (contentRef.current) {
      observer.observe(contentRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
      if (contentRef.current) {
        observer.unobserve(contentRef.current);
      }
    };
  }, []);

  return (
    <section id="asociate" className="bg-blue-50 py-20">
      <div
        ref={sectionRef}
        className="section-padding opacity-0 translate-y-10 transition-all duration-1000"
      >
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-block px-3 py-1 mb-4 bg-blue-100 rounded-full">
              <span className="text-primary text-sm font-medium">Asóciate</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Únete a la asociación</h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Si formas parte del personal informático de la administración de Castilla y León o de sus organismos autónomos háznos llegar tu solicitud.
            </p>
          </div>
          
          <div 
            ref={contentRef}
            className="bg-white p-8 rounded-lg shadow-sm border border-border opacity-0 translate-y-10 transition-all duration-1000 delay-300"
          >
            <h3 className="text-2xl font-bold mb-6">Proceso de inscripción</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1 p-2 bg-blue-50 rounded-full">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium">Paso 1: Descarga el formulario</h4>
                  <p className="text-muted-foreground mb-4">
                    Descarga nuestro formulario de inscripción PDF rellenable y complétalo con tus datos.
                  </p>
                  <a 
                    href="/formularioinscripcionapiacyl_final-1.pdf" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex"
                  >
                    <Button>
                      <FileText className="mr-2" />
                      Descargar formulario PDF
                    </Button>
                  </a>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1 p-2 bg-blue-50 rounded-full">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium">Paso 2: Envía el formulario firmado</h4>
                  <p className="text-muted-foreground mb-2">
                    Una vez completado, firma el formulario (con certificado electrónico o de forma manuscrita) y envíalo a:
                  </p>
                  <a 
                    href="mailto:info.apiacyl@gmail.com" 
                    className="text-primary font-medium hover:underline"
                  >
                    info.apiacyl@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg mt-8">
                <p className="text-sm text-muted-foreground">
                  <strong>Nota:</strong> Tras recibir tu solicitud, nos pondremos en contacto contigo para confirmar tu inscripción y proporcionarte información adicional sobre cómo participar en nuestras actividades.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Join;
